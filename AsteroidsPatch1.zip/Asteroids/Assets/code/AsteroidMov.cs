﻿using UnityEngine;
using System.Collections;


public class AsteroidMov : MonoBehaviour {
	float speed;
	float offSetStart;
	float dir;
	float oriPosY;
	// Use this for initialization
	void Start () {
		speed = Random.Range(0.005f, 0.02f);//Get a random speed
		offSetStart = Random.Range(-10.0f, -1.0f);//Get a random position for start moving
		dir = Random.Range(-0.008f, 0.008f);//Get a random direccion to avoid straight line

		oriPosY = GetComponent<Transform> ().position.y; //Saves the original position in y for future respawn
		GetComponent<Transform> ().position = (new Vector3 (offSetStart, oriPosY,0.0f));// Sets the position for start
	}

	// Update is called once per frame
	void Update () {
		if (GetComponent<Transform> ().position.x <  10 ) {
			GetComponent<Transform> ().Translate (new Vector2 (speed, dir));// upadtes the position until leave the screen
		} else {
			speed = Random.Range(0.005f, 0.02f);//Get new speed
			offSetStart = Random.Range(-15.0f, -10.0f);//Get new position
			dir = Random.Range(-0.008f, 0.008f);//Get new direction

			GetComponent<Transform> ().position = (new Vector3 (offSetStart, oriPosY,0.0f));//Sets the new position for start
		}
	}
}
