﻿using UnityEngine;
using System.Collections;

public class AsteroidMovV : MonoBehaviour {
	private float speed;
	private float offSetStart;
	private float dir;
	private float oriPosX;

	// Use this for initialization
	void Start () {
		speed = Random.Range(-0.005f, -0.03f);//Get a random speed
		offSetStart = Random.Range(20.0f, 0.0f);//Get a random position for start moving
		dir = Random.Range(-0.008f, 0.008f);//Get a random direccion to avoid straight line

		oriPosX = GetComponent<Transform> ().position.x;//Saves the original position in y for future respawn
		GetComponent<Transform> ().position = (new Vector3 (oriPosX, offSetStart,0.0f));// Sets the position for start
	}

	// Update is called once per frame
	void Update () {
		if (GetComponent<Transform> ().position.y >  -6 ) {
			GetComponent<Transform> ().Translate (new Vector2 (dir,speed));// upadtes the position until leave the screen
		} else {
			speed = Random.Range(-0.005f, -0.03f);//Get a new speed
			offSetStart = Random.Range(20.0f, 10.0f);//Get new position
			dir = Random.Range(-0.008f, 0.008f);//Get new diection
			GetComponent<Transform> ().position = (new Vector3 (oriPosX, offSetStart,0.0f));//Sets the new position for start
		}
	}
}
